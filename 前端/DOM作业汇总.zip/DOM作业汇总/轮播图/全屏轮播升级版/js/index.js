$(document).ready(function(){
	// 通过假数据控制产生li的个数  生成li标签
	var images = ["01.jpg","02.jpg","03.jpg","04.jpg","05.jpg"]
	for(var i = 0; i < images.length; i++) {
		var newLi = document.createElement("li");
		$("#bannerList").append(newLi);
	}
	$("#bannerList>li:first-child").addClass("current"); 
	$("#bannerList>li:last-child").addClass("show"); 

	//全屏轮播代码
	var timer = null;
	var index = 0;
	// 开始自动轮播	先加加  后判断  再执行
	timer = setInterval(autoplay, 3000)
	function autoplay() {
		index++;
		if(index > $("li").length - 1) {
			index = 0;
		}
		//排他思想添加当前显示zindex
		for(var i = 0; i < $("li").length; i++) {
			$("li")[i].removeAttribute("class")
			$("li")[i].removeAttribute("style")
		}
		$("li")[index].setAttribute("class","current");
		if(index === 0) {
			$("li")[$("li").length - 1].setAttribute("class","show");
		}else {
			$("li")[index - 1].setAttribute("class","show");
		}
		var that = $("li")[index]
		$(that).css({width:"0",right:"0"})
		$(that).animate({width: window.innerWidth + "px"}, 1000);
	}
	//鼠标经过，停止定时器，显示盒子  鼠标离开隐藏盒子；
	$("#banner").hover(function () {
  		$("#banner>a").show();
  		clearInterval(timer)
  	},function () {
  		$("#banner>a").hide();
  		timer = setInterval(autoplay, 3000)
  	}); 
  	//右边边点击	事件截流 采用setTimeout 缓一下执行
	var last = null;
  	$("#clickRight").click(function() {
  		// 使用定时器之前先清除定时器
  		clearInterval(timer)
  		clearTimeout(last)
		last = setTimeout(autoplay, 500)
  	});
  	//左边点击
  	$("#clickLeft").click(function() {
  		// 使用定时器之前先清除定时器
  		clearInterval(timer)
  		clearTimeout(last)
  		last = setTimeout(function() {
			if(index > $("li").length - 1) {
				index = 0;
			}
			//排他思想添加当前显示zindex
			for(var i = 0; i < $("li").length; i++) {
				$("li")[i].removeAttribute("class")
			}
			$("li")[index].setAttribute("class","show");
			var that = $("li")[index + 1]
			if(index === $("li").length - 1) {
				$("li")[0].setAttribute("class","current");
				$("li:first-child").css({width:"0",left:"0"})
				$("li:first-child").animate({width: window.innerWidth + "px"}, 1000);
			}else {
				$("li")[index + 1].setAttribute("class","current");
				$(that).css({width:"0",left:"0"})
			}
			$(that).animate({width: window.innerWidth + "px"}, 1000);
			index++;
		}, 500)
  	});

}); 